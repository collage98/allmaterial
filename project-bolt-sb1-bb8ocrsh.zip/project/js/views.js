// ============================================================
// ITStudyHub — Views
// Renders all pages: Home/Dashboard, Semesters, Subject detail,
// Practicals, Practical detail, Academic Resources, Bookmarks.
// ============================================================

import { SEMESTERS, SEARCH_INDEX, THEMES, TAGLINE, DEFAULT_SITE_NAME } from './data.js';
import { state, addRecent, isBookmarked } from './state.js';
import { icon } from './icons.js';
import {
  escapeHtml, breadcrumb, bookmarkButton, pdfViewer, codeViewer,
  emptyState, getSemester, getSubject, getUnit, toast,
} from './ui.js';

// Helper: build a bookmark item object
function bmItem(id, label, sub, type, route) {
  return { id, label, sub, type, route: route || currentRouteString() };
}

function currentRouteString() {
  return window.location.hash.slice(1) || '/';
}

// ============================================================
// HOME / DASHBOARD
// ============================================================
export function viewHome() {
  const totalSubjects = SEMESTERS.reduce((a, s) => a + s.subjects.length, 0);
  const totalUnits = SEMESTERS.reduce((a, s) => a + s.subjects.reduce((b, sub) => b + sub.units.length, 0), 0);
  const totalPracticals = SEMESTERS.reduce((a, s) => a + s.subjects.length, 0);
  const totalResources = SEMESTERS.reduce((a, s) => a + s.subjects.length * 3, 0);

  const hero = `
    <section class="hero">
      <div class="container">
        <div class="hero-grid">
          <div>
            <div class="hero-badge">${icon('graduationCap')} ${escapeHtml(TAGLINE)}</div>
            <h1 class="hero-title">Welcome to <span class="grad">${escapeHtml(state.siteName)}</span></h1>
            <p class="hero-subtitle">Your Complete IT Study, Practical &amp; Exam Preparation Hub</p>
            <p class="hero-desc">Access structured study materials, practical code, past papers, and academic resources across all 8 semesters — all in one professional platform.</p>
            <div class="hero-actions">
              <a href="#/semesters" class="btn btn-primary btn-lg" data-link="semesters">${icon('layers')} Explore Semesters</a>
              <a href="#/practicals" class="btn btn-outline btn-lg" data-link="practicals">${icon('code')} Practicals</a>
            </div>
            <div class="hero-search" id="hero-search-mount"></div>
          </div>
          <div class="hero-visual" aria-hidden="true">
            <div class="hc-center">${icon('academic')}</div>
            <div class="hero-card-float hc-1"><div class="hc-icon" style="background:var(--primary)">${icon('book')}</div><div><div class="hc-text">8 Semesters</div><div class="hc-sub">56 Subjects</div></div></div>
            <div class="hero-card-float hc-2"><div class="hc-icon" style="background:var(--accent)">${icon('code')}</div><div><div class="hc-text">Practicals</div><div class="hc-sub">Code &amp; Viva</div></div></div>
            <div class="hero-card-float hc-3"><div class="hc-icon" style="background:var(--primary-dark)">${icon('fileText')}</div><div><div class="hc-text">Resources</div><div class="hc-sub">Assignments &amp; Papers</div></div></div>
          </div>
        </div>
      </div>
    </section>
  `;

  const dashStats = `
    <section class="section">
      <div class="container">
        <div class="section-header">
          <h2 class="section-title">Student Dashboard</h2>
          <p class="section-subtitle">Overview of your learning resources</p>
        </div>
        <div class="stats-grid mb-24">
          ${statCard(icon('layers'), 'Total Semesters', SEMESTERS.length, 'var(--primary)')}
          ${statCard(icon('book'), 'Total Subjects', totalSubjects, 'var(--accent)')}
          ${statCard(icon('fileText'), 'Total Units', totalUnits, 'var(--primary-dark)')}
          ${statCard(icon('code'), 'Practicals', totalPracticals, '#0891b2')}
          ${statCard(icon('clipboard'), 'Assignments', totalResources, '#7c3aed')}
          ${statCard(icon('star'), 'Bookmarked', state.bookmarks.length, 'var(--warning)')}
        </div>
        <div class="dash-grid">
          <div class="dash-panel">
            <h3>${icon('clock')} Recently Viewed</h3>
            ${state.recent.length === 0 ? emptyState('Nothing here yet', 'Resources you open will appear here for quick access.', 'clock') :
              state.recent.slice(0, 6).map((r) => recentItem(r)).join('')}
          </div>
          <div class="dash-panel">
            <h3>${icon('bookmark')} Recent Bookmarks</h3>
            ${state.bookmarks.length === 0 ? emptyState('No bookmarks', 'Bookmark subjects, units, practicals and more to find them quickly.', 'bookmark') :
              state.bookmarks.slice(0, 6).map((r) => recentItem(r)).join('')}
          </div>
        </div>
      </div>
    </section>
  `;

  const semPreview = `
    <section class="section">
      <div class="container">
        <div class="section-header">
          <h2 class="section-title">Browse Semesters</h2>
          <p class="section-subtitle">Click any semester to explore its subjects and units</p>
        </div>
        <div class="cards-grid">
          ${SEMESTERS.map((s) => semesterCard(s)).join('')}
        </div>
      </div>
    </section>
  `;

  return hero + dashStats + semPreview;
}

function statCard(ic, label, value, bg) {
  return `<div class="stat-card"><div class="stat-icon" style="background:${bg}">${ic}</div><div class="stat-value">${value}</div><div class="stat-label">${escapeHtml(label)}</div></div>`;
}

function recentItem(r) {
  const routeStr = typeof r.route === 'string' ? r.route : `/${r.route.view}`;
  return `<a href="#${routeStr}" class="list-item" data-link="${routeStr.slice(1)}"><div class="li-icon">${icon(iconForType(r.type))}</div><div class="li-content"><div class="li-title">${escapeHtml(r.label)}</div><div class="li-sub">${escapeHtml(r.type)}${r.sub ? ' • ' + escapeHtml(r.sub) : ''}</div></div><div class="li-action">${icon('chevronRight')}</div></a>`;
}

function iconForType(type) {
  const map = { Semester: 'layers', Subject: 'book', Unit: 'fileText', Practical: 'code', Assignment: 'clipboard', Journal: 'notebook', Paper: 'fileText', 'Study Material': 'bookOpen', 'Important Questions': 'helpCircle' };
  return map[type] || 'folder';
}

// ============================================================
// SEMESTER CARD
// ============================================================
export function semesterCard(s) {
  const route = `semester/${s.number}`;
  const bmId = `sem-${s.number}`;
  const bm = bmItem(bmId, s.title, s.theme, 'Semester', route);
  return `
    <div class="card">
      <div class="flex items-center justify-between">
        <span class="card-badge">${icon('layers')} Semester ${s.number}</span>
        ${bookmarkButton(bm)}
      </div>
      <h3 class="card-title">${escapeHtml(s.title)}</h3>
      <p class="card-subtitle">${escapeHtml(s.theme)}</p>
      <div class="card-meta">
        <span class="card-meta-item">${icon('book')} ${s.subjectCount} Subjects</span>
        <span class="card-meta-item">${icon('fileText')} ${s.unitCount} Units</span>
        <span class="card-meta-item">${icon('code')} Practicals</span>
      </div>
      <div class="card-actions">
        <a href="#/${route}" class="btn btn-primary btn-sm" data-link="${route}">${icon('eye')} View Semester</a>
      </div>
    </div>
  `;
}

// ============================================================
// SEMESTER DETAIL
// ============================================================
export function viewSemester(semNum) {
  const sem = getSemester(semNum);
  if (!sem) return notFound('Semester not found');
  addRecent(bmItem(`sem-${sem.number}`, sem.title, sem.theme, 'Semester', `semester/${sem.number}`));
  return `
    <div class="container">
      <div class="page-header">
        ${breadcrumb([{ label: 'Home', route: '' }, { label: 'Semesters', route: 'semesters' }, { label: sem.title }])}
        <div class="flex items-center justify-between flex-wrap gap-12">
          <div>
            <h1 class="page-title">${escapeHtml(sem.title)}</h1>
            <p class="page-subtitle">${escapeHtml(sem.theme)} • ${sem.subjectCount} subjects • ${sem.unitCount} units</p>
          </div>
          <div class="flex gap-8">
            <a href="#/semester/${sem.number}/academic" class="btn btn-outline btn-sm" data-link="semester/${sem.number}/academic">${icon('clipboard')} Academic Resources</a>
            ${bookmarkButton(bmItem(`sem-${sem.number}`, sem.title, sem.theme, 'Semester', `semester/${sem.number}`))}
          </div>
        </div>
      </div>
      <div class="cards-grid compact">
        ${sem.subjects.map((sub) => subjectCard(sem, sub)).join('')}
      </div>
      <div class="section"></div>
    </div>
  `;
}

export function subjectCard(sem, sub) {
  const route = `semester/${sem.number}/subject/${sub.index}`;
  const bm = bmItem(sub.id, sub.name, `Semester ${sem.number}`, 'Subject', route);
  return `
    <div class="card">
      <div class="flex items-center justify-between">
        <span class="card-badge">${icon('book')} Subject ${sub.index + 1}</span>
        ${bookmarkButton(bm)}
      </div>
      <h3 class="card-title">${escapeHtml(sub.name)}</h3>
      <p class="card-subtitle">${sem.title} • 5 Units + 1 Practical</p>
      <div class="card-meta">
        <span class="card-meta-item">${icon('fileText')} 5 Units</span>
        <span class="card-meta-item">${icon('code')} Practical</span>
        <span class="card-meta-item">${icon('clipboard')} Resources</span>
      </div>
      <div class="card-actions">
        <a href="#/${route}" class="btn btn-primary btn-sm" data-link="${route}">${icon('eye')} Open Subject</a>
      </div>
    </div>
  `;
}

// ============================================================
// SUBJECT DETAIL
// ============================================================
export function viewSubject(semNum, subIndex, opts = {}) {
  const sub = getSubject(semNum, subIndex);
  if (!sub) return notFound('Subject not found');
  const sem = getSemester(semNum);
  const activeUnit = opts.unit ? Number(opts.unit) : 1;
  const activeTab = opts.tab || 'material';
  addRecent(bmItem(sub.id, sub.name, `Semester ${semNum}`, 'Subject', `semester/${semNum}/subject/${subIndex}`));

  const unitsHtml = sub.units.map((u) => {
    const open = u.number === activeUnit;
    return `
      <div class="accordion-item ${open ? 'open' : ''}" data-unit="${u.number}">
        <button class="accordion-header" data-toggle-unit="${u.number}" aria-expanded="${open}">
          <span class="ah-left"><span class="ah-num">${u.number}</span><span class="ah-title">${escapeHtml(u.title)}</span></span>
          ${icon('chevronDown')}
        </button>
        <div class="accordion-body"><div class="accordion-body-inner">${unitContent(sub, u, activeTab)}</div></div>
      </div>
    `;
  }).join('');

  return `
    <div class="container">
      <div class="page-header">
        ${breadcrumb([
          { label: 'Home', route: '' },
          { label: 'Semesters', route: 'semesters' },
          { label: sem.title, route: `semester/${semNum}` },
          { label: sub.name },
        ])}
        <div class="flex items-center justify-between flex-wrap gap-12">
          <div>
            <h1 class="page-title">${escapeHtml(sub.name)}</h1>
            <p class="page-subtitle">${escapeHtml(sem.title)} • Subject ${sub.index + 1}</p>
          </div>
          <div class="flex gap-8">
            <a href="#/semester/${semNum}/subject/${subIndex}/practical" class="btn btn-outline btn-sm" data-link="semester/${semNum}/subject/${subIndex}/practical">${icon('code')} Practical</a>
            <a href="#/semester/${semNum}/subject/${subIndex}/academic" class="btn btn-outline btn-sm" data-link="semester/${semNum}/subject/${subIndex}/academic">${icon('clipboard')} Academic</a>
            ${bookmarkButton(bmItem(sub.id, sub.name, `Semester ${semNum}`, 'Subject', `semester/${semNum}/subject/${subIndex}`))}
          </div>
        </div>
      </div>
      <div class="tabs">
        ${sub.units.map((u) => `<button class="tab ${u.number === activeUnit ? 'active' : ''}" data-unit-tab="${u.number}">Unit ${u.number}</button>`).join('')}
      </div>
      <div class="accordion">${unitsHtml}</div>
      <div class="section"></div>
    </div>
  `;
}

function unitContent(sub, unit, activeTab) {
  const tabs = [
    { id: 'material', label: 'Study Material', ic: 'bookOpen' },
    { id: 'notes', label: 'Notes', ic: 'penTool' },
    { id: 'questions', label: 'Important Questions', ic: 'helpCircle' },
    { id: 'reference', label: 'Reference', ic: 'book' },
  ];
  const pdfKey = unit.id;
  return `
    <div class="unit-tabs">
      ${tabs.map((t) => `<button class="unit-tab ${t.id === activeTab ? 'active' : ''}" data-unit-content-tab="${t.id}" data-unit-num="${unit.number}">${icon(t.ic)} ${escapeHtml(t.label)}</button>`).join('')}
    </div>
    <div class="unit-content">
      ${renderUnitTab(sub, unit, activeTab, pdfKey)}
    </div>
  `;
}

function renderUnitTab(sub, unit, tab, pdfKey) {
  if (tab === 'material') {
    return `<p>${escapeHtml(unit.studyMaterial)}</p>${pdfViewer(pdfKey, 'Study Material PDF')}`;
  }
  if (tab === 'notes') {
    return `<p>${escapeHtml(unit.notes)}</p>`;
  }
  if (tab === 'questions') {
    const bm = bmItem(`${unit.id}-questions`, `${unit.title} — Questions`, sub.name, 'Important Questions', `semester/${sub.semester}/subject/${sub.index}/unit/${unit.number}/questions`);
    return `<h4>Important Questions</h4>
      <ul class="bullet">${unit.importantQuestions.map((q) => `<li>${escapeHtml(q)}</li>`).join('')}</ul>
      <div class="mt-16">${bookmarkButton(bm)}</div>`;
  }
  if (tab === 'reference') {
    return `<p>${escapeHtml(unit.referenceMaterial)}</p>${pdfViewer(`${pdfKey}-ref`, 'Reference PDF')}`;
  }
  return '';
}

// ============================================================
// SEMESTERS LIST
// ============================================================
export function viewSemesters() {
  return `
    <div class="container">
      <div class="page-header">
        ${breadcrumb([{ label: 'Home', route: '' }, { label: 'Semesters' }])}
        <h1 class="page-title">All Semesters</h1>
        <p class="page-subtitle">8 semesters • 56 subjects • 280 units of study content</p>
      </div>
      <div class="cards-grid">
        ${SEMESTERS.map((s) => semesterCard(s)).join('')}
      </div>
      <div class="section"></div>
    </div>
  `;
}

// ============================================================
// PRACTICALS LIST
// ============================================================
export function viewPracticals() {
  return `
    <div class="container">
      <div class="page-header">
        ${breadcrumb([{ label: 'Home', route: '' }, { label: 'Practicals' }])}
        <h1 class="page-title">Practicals</h1>
        <p class="page-subtitle">Browse practical assignments by semester and subject</p>
      </div>
      ${SEMESTERS.map((sem) => `
        <div class="mb-24">
          <h3 class="flex items-center gap-8 mb-16" style="font-size:1.1rem;font-weight:700">${icon('layers')} ${escapeHtml(sem.title)}</h3>
          <div class="cards-grid compact">
            ${sem.subjects.map((sub) => `
              <a href="#/semester/${sem.number}/subject/${sub.index}/practical" class="card" data-link="semester/${sem.number}/subject/${sub.index}/practical">
                <span class="card-badge">${icon('code')} Practical ${sub.index + 1}</span>
                <h3 class="card-title">${escapeHtml(sub.name)}</h3>
                <p class="card-subtitle">${escapeHtml(sub.practical.title.split('—')[1] || sub.practical.title)}</p>
                <div class="card-meta"><span class="card-meta-item">${icon('terminal')} View Code &amp; Viva</span></div>
              </a>
            `).join('')}
          </div>
        </div>
      `).join('')}
      <div class="section"></div>
    </div>
  `;
}

// ============================================================
// PRACTICAL DETAIL
// ============================================================
export function viewPracticalDetail(semNum, subIndex) {
  const sub = getSubject(semNum, subIndex);
  if (!sub) return notFound('Practical not found');
  const sem = getSemester(semNum);
  const p = sub.practical;
  addRecent(bmItem(p.id, p.title, sub.name, 'Practical', `semester/${semNum}/subject/${subIndex}/practical`));

  return `
    <div class="container">
      <div class="page-header">
        ${breadcrumb([
          { label: 'Home', route: '' },
          { label: 'Practicals', route: 'practicals' },
          { label: sem.title, route: `semester/${semNum}` },
          { label: p.title },
        ])}
        <div class="flex items-center justify-between flex-wrap gap-12">
          <div>
            <h1 class="page-title">${escapeHtml(p.title)}</h1>
            <p class="page-subtitle">${escapeHtml(sub.name)} • ${escapeHtml(sem.title)}</p>
          </div>
          ${bookmarkButton(bmItem(p.id, p.title, sub.name, 'Practical', `semester/${semNum}/subject/${subIndex}/practical`))}
        </div>
      </div>
      <div class="practical-card">
        <div class="practical-section">
          <h4>${icon('target')} Problem Statement</h4>
          <div class="info-box"><p>${escapeHtml(p.problemStatement)}</p></div>
        </div>
        <div class="practical-section">
          <h4>${icon('lightbulb')} Objective</h4>
          <p>${escapeHtml(p.objective)}</p>
        </div>
        <div class="practical-section">
          <h4>${icon('code')} Source Code</h4>
          ${codeViewer(p.sourceCode, 'C')}
        </div>
        <div class="practical-section">
          <h4>${icon('bookOpen')} Explanation</h4>
          <p>${escapeHtml(p.explanation)}</p>
        </div>
        <div class="practical-section">
          <h4>${icon('terminal')} Expected Output</h4>
          <div class="code-viewer"><pre class="code-block" style="color:#8b949e;background:#161b22">${escapeHtml(p.output)}</pre></div>
        </div>
        <div class="practical-section">
          <h4>${icon('helpCircle')} Viva Questions</h4>
          <ul>${p.vivaQuestions.map((q) => `<li>${escapeHtml(q)}</li>`).join('')}</ul>
        </div>
        <div class="practical-section">
          <h4>${icon('fileText')} Reference PDF</h4>
          ${pdfViewer(`${p.id}-ref`, 'Practical Reference PDF')}
        </div>
      </div>
      <div class="section"></div>
    </div>
  `;
}

// ============================================================
// ACADEMIC RESOURCES
// ============================================================
export function viewAcademicList(semNum, subIndex) {
  // If no subject specified, show semester picker + subject list
  if (semNum == null) {
    return `
      <div class="container">
        <div class="page-header">
          ${breadcrumb([{ label: 'Home', route: '' }, { label: 'Academic Resources' }])}
          <h1 class="page-title">Academic Resources</h1>
          <p class="page-subtitle">Assignments, Journals &amp; Papers organized by semester and subject</p>
        </div>
        <div class="resource-nav" id="academic-sem-nav">
          ${SEMESTERS.map((s) => `<a href="#/academic/semester/${s.number}" class="resource-pill ${semNum == s.number ? 'active' : ''}" data-link="academic/semester/${s.number}">${icon('layers')} ${escapeHtml(s.title)}</a>`).join('')}
        </div>
        ${semNum != null ? renderAcademicSubjects(getSemester(semNum)) : `<p class="text-center" style="color:var(--text-secondary)">Select a semester above to view subjects.</p>`}
        <div class="section"></div>
      </div>
    `;
  }
  const sem = getSemester(semNum);
  if (!sem) return notFound('Semester not found');
  return `
    <div class="container">
      <div class="page-header">
        ${breadcrumb([{ label: 'Home', route: '' }, { label: 'Academic Resources', route: 'academic' }, { label: sem.title }])}
        <h1 class="page-title">Academic Resources — ${escapeHtml(sem.title)}</h1>
        <p class="page-subtitle">Choose a subject to view its Assignment, Journal, and Paper</p>
      </div>
      <div class="resource-nav">
        ${SEMESTERS.map((s) => `<a href="#/academic/semester/${s.number}" class="resource-pill ${s.number === sem.number ? 'active' : ''}" data-link="academic/semester/${s.number}">${icon('layers')} ${escapeHtml(s.title)}</a>`).join('')}
      </div>
      ${renderAcademicSubjects(sem)}
      <div class="section"></div>
    </div>
  `;
}

function renderAcademicSubjects(sem) {
  return `
    <div class="cards-grid compact">
      ${sem.subjects.map((sub) => `
        <a href="#/academic/semester/${sem.number}/subject/${sub.index}" class="card" data-link="academic/semester/${sem.number}/subject/${sub.index}">
          <span class="card-badge">${icon('book')} Subject ${sub.index + 1}</span>
          <h3 class="card-title">${escapeHtml(sub.name)}</h3>
          <p class="card-subtitle">Assignment • Journal • Paper</p>
          <div class="card-meta">
            <span class="card-meta-item">${icon('clipboard')} Assignment</span>
            <span class="card-meta-item">${icon('notebook')} Journal</span>
            <span class="card-meta-item">${icon('fileText')} Paper</span>
          </div>
        </a>
      `).join('')}
    </div>
  `;
}

export function viewAcademicSubject(semNum, subIndex, activeRes = 'assignment') {
  const sub = getSubject(semNum, subIndex);
  if (!sub) return notFound('Subject not found');
  const sem = getSemester(semNum);
  const res = sub.academic[activeRes];
  addRecent(bmItem(res.id, res.title, sub.name, capFirst(activeRes), `academic/semester/${semNum}/subject/${subIndex}/${activeRes}`));

  const resTypes = [
    { id: 'assignment', label: 'Assignment', ic: 'clipboard' },
    { id: 'journal', label: 'Journal', ic: 'notebook' },
    { id: 'paper', label: 'Paper', ic: 'fileText' },
  ];

  return `
    <div class="container">
      <div class="page-header">
        ${breadcrumb([
          { label: 'Home', route: '' },
          { label: 'Academic Resources', route: 'academic' },
          { label: sem.title, route: `academic/semester/${semNum}` },
          { label: sub.name },
        ])}
        <div class="flex items-center justify-between flex-wrap gap-12">
          <div>
            <h1 class="page-title">${escapeHtml(sub.name)}</h1>
            <p class="page-subtitle">${escapeHtml(sem.title)} • Academic Resources</p>
          </div>
        </div>
      </div>
      <div class="resource-nav">
        ${resTypes.map((r) => `<a href="#/academic/semester/${semNum}/subject/${subIndex}/${r.id}" class="resource-pill ${r.id === activeRes ? 'active' : ''}" data-link="academic/semester/${semNum}/subject/${subIndex}/${r.id}">${icon(r.ic)} ${escapeHtml(r.label)}</a>`).join('')}
      </div>
      <div class="practical-card">
        <div class="flex items-center justify-between mb-16">
          <h3 style="font-size:1.2rem;font-weight:700">${icon(resTypes.find((r) => r.id === activeRes).ic)} ${escapeHtml(res.title)}</h3>
          ${bookmarkButton(bmItem(res.id, res.title, sub.name, capFirst(activeRes), `academic/semester/${semNum}/subject/${subIndex}/${activeRes}`))}
        </div>
        <p style="color:var(--text-secondary);margin-bottom:16px">${escapeHtml(res.description)}</p>
        ${pdfViewer(res.id, `${capFirst(activeRes)} PDF`)}
      </div>
      <div class="section"></div>
    </div>
  `;
}

// Direct academic detail (from search)
export function viewAcademicDetail(semNum, subIndex, resType) {
  return viewAcademicSubject(semNum, subIndex, resType);
}

function capFirst(s) { return s.charAt(0).toUpperCase() + s.slice(1); }

// ============================================================
// BOOKMARKS
// ============================================================
export function viewBookmarks() {
  if (state.bookmarks.length === 0) {
    return `
      <div class="container">
        <div class="page-header">
          ${breadcrumb([{ label: 'Home', route: '' }, { label: 'Bookmarks' }])}
          <h1 class="page-title">Bookmarks</h1>
        </div>
        ${emptyState('No bookmarks yet', 'Tap the bookmark icon on any subject, unit, practical, assignment, journal, or paper to save it here for quick access.', 'bookmark')}
        <div class="section"></div>
      </div>
    `;
  }
  // Group by type
  const groups = {};
  state.bookmarks.forEach((b) => {
    if (!groups[b.type]) groups[b.type] = [];
    groups[b.type].push(b);
  });
  const groupOrder = ['Semester', 'Subject', 'Unit', 'Study Material', 'Important Questions', 'Practical', 'Assignment', 'Journal', 'Paper'];

  return `
    <div class="container">
      <div class="page-header">
        ${breadcrumb([{ label: 'Home', route: '' }, { label: 'Bookmarks' }])}
        <div class="flex items-center justify-between flex-wrap gap-12">
          <div>
            <h1 class="page-title">Bookmarks</h1>
            <p class="page-subtitle">${state.bookmarks.length} saved resource${state.bookmarks.length === 1 ? '' : 's'}</p>
          </div>
          <button class="btn btn-outline btn-sm" data-clear-bookmarks>${icon('trash')} Clear All</button>
        </div>
      </div>
      ${groupOrder.filter((g) => groups[g]).map((g) => `
        <div class="mb-24">
          <h3 class="flex items-center gap-8 mb-16" style="font-size:1rem;font-weight:700;color:var(--text-secondary)">${icon(iconForType(g))} ${escapeHtml(g)} (${groups[g].length})</h3>
          <div class="list">
            ${groups[g].map((b) => bookmarkListItem(b)).join('')}
          </div>
        </div>
      `).join('')}
      <div class="section"></div>
    </div>
  `;
}

function bookmarkListItem(b) {
  const routeStr = typeof b.route === 'string' ? b.route : `/${b.route.view}`;
  return `
    <div class="list-item">
      <a href="#${routeStr}" data-link="${routeStr.slice(1)}" style="color:inherit;display:flex;flex:1;min-width:0;align-items:center;gap:12px;text-decoration:none">
        <div class="li-icon">${icon(iconForType(b.type))}</div>
        <div style="flex:1;min-width:0">
          <div class="li-title">${escapeHtml(b.label)}</div>
          <div class="li-sub">${escapeHtml(b.type)}${b.sub ? ' • ' + escapeHtml(b.sub) : ''}</div>
        </div>
      </a>
      <button class="bookmark-btn active" data-bookmark='${JSON.stringify(b).replace(/'/g, '&#39;')}'>${icon('bookmarkFill')}</button>
    </div>
  `;
}

// ============================================================
// SEARCH RESULTS PAGE
// ============================================================
export function viewSearch(query) {
  if (!query || !query.trim()) {
    return `<div class="container"><div class="page-header">${breadcrumb([{ label: 'Home', route: '' }, { label: 'Search' }])}<h1 class="page-title">Search</h1></div>${emptyState('Type to search', 'Use the search bar above to find semesters, subjects, units, practicals, and more.', 'search')}<div class="section"></div></div>`;
  }
  const q = query.toLowerCase();
  const results = SEARCH_INDEX.filter((item) => item.label.toLowerCase().includes(q) || item.type.toLowerCase().includes(q) || (item.sub && item.sub.toLowerCase().includes(q)));
  const grouped = {};
  results.forEach((r) => { if (!grouped[r.type]) grouped[r.type] = []; grouped[r.type].push(r); });
  const groupOrder = ['Semester', 'Subject', 'Unit', 'Study Material', 'Important Questions', 'Practical', 'Assignment', 'Journal', 'Paper'];

  return `
    <div class="container">
      <div class="page-header">
        ${breadcrumb([{ label: 'Home', route: '' }, { label: 'Search' }])}
        <h1 class="page-title">Search Results</h1>
        <p class="page-subtitle">${results.length} result${results.length === 1 ? '' : 's'} for "${escapeHtml(query)}"</p>
      </div>
      ${results.length === 0 ? emptyState('No results found', 'Try different keywords like a subject name, semester number, or topic.', 'search') :
        groupOrder.filter((g) => grouped[g]).map((g) => `
          <div class="mb-24">
            <h3 class="flex items-center gap-8 mb-16" style="font-size:1rem;font-weight:700;color:var(--text-secondary)">${icon(iconForType(g))} ${escapeHtml(g)} (${grouped[g].length})</h3>
            <div>${grouped[g].map((r) => searchResultItem(r)).join('')}</div>
          </div>
        `).join('')}
      <div class="section"></div>
    </div>
  `;
}

function searchResultItem(r) {
  const routeStr = typeof r.route === 'string' ? r.route : `/${r.route.view}`;
  return `<a href="#${routeStr}" class="list-item" data-link="${routeStr.slice(1)}"><div class="li-icon">${icon(iconForType(r.type))}</div><div class="li-content"><div class="li-title">${escapeHtml(r.label)}</div><div class="li-sub">${escapeHtml(r.type)}${r.sub ? ' • ' + escapeHtml(r.sub) : ''}</div></div><div class="li-action">${icon('chevronRight')}</div></a>`;
}

// ============================================================
// NOT FOUND
// ============================================================
export function notFound(msg = 'Page not found') {
  return `<div class="container"><div class="page-header"></div>${emptyState(msg, 'The page you are looking for does not exist.', 'alertCircle')}<div class="section"></div></div>`;
}
