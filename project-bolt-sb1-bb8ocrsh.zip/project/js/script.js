// ============================================================
// ITStudyHub — Main App
// Routing, header/nav, search, settings panel, profile panel,
// mobile menu, event delegation, and initial render.
// ============================================================

import { SEMESTERS, SEARCH_INDEX, THEMES, DEFAULT_SITE_NAME, TAGLINE } from './data.js';
import { state, applyTheme, applyMode, setTheme, setMode, setSiteName, setProfile, removeBookmark } from './state.js';
import { icon } from './icons.js';
import {
  escapeHtml, toast, handleBookmarkClick, handlePdfUpload, handleRemovePdf, handleCopyCode,
} from './ui.js';
import {
  viewHome, viewSemesters, viewSemester, viewSubject, viewPracticals,
  viewPracticalDetail, viewAcademicList, viewAcademicSubject, viewAcademicDetail,
  viewBookmarks, viewSearch, notFound,
} from './views.js';

// ---------- Router ----------
function parseRoute() {
  const hash = window.location.hash.slice(1) || '/';
  const parts = hash.split('/').filter(Boolean);
  return { parts, raw: hash };
}

function renderRoute() {
  const { parts } = parseRoute();
  const app = document.getElementById('app');
  let html;

  if (parts.length === 0) {
    html = viewHome();
  } else if (parts[0] === 'semesters') {
    html = viewSemesters();
  } else if (parts[0] === 'semester' && parts[1]) {
    const semNum = Number(parts[1]);
    if (parts[2] === 'subject' && parts[3] != null) {
      const subIndex = Number(parts[3]);
      if (parts[4] === 'practical') {
        html = viewPracticalDetail(semNum, subIndex);
      } else if (parts[4] === 'academic') {
        html = viewAcademicSubject(semNum, subIndex, 'assignment');
      } else if (parts[4] === 'unit' && parts[5]) {
        html = viewSubject(semNum, subIndex, { unit: Number(parts[5]), tab: parts[6] || 'material' });
      } else {
        html = viewSubject(semNum, subIndex);
      }
    } else if (parts[2] === 'academic') {
      html = viewAcademicList(semNum);
    } else {
      html = viewSemester(semNum);
    }
  } else if (parts[0] === 'practicals') {
    html = viewPracticals();
  } else if (parts[0] === 'academic') {
    if (parts[1] === 'semester' && parts[2]) {
      const semNum = Number(parts[2]);
      if (parts[3] === 'subject' && parts[4] != null) {
        const subIndex = Number(parts[4]);
        const resType = parts[5] || 'assignment';
        html = viewAcademicSubject(semNum, subIndex, resType);
      } else {
        html = viewAcademicList(semNum);
      }
    } else {
      html = viewAcademicList(null);
    }
  } else if (parts[0] === 'bookmarks') {
    html = viewBookmarks();
  } else if (parts[0] === 'search') {
    const query = decodeURIComponent(parts.slice(1).join(' ') || '');
    html = viewSearch(query);
  } else {
    html = notFound();
  }

  app.innerHTML = `<div class="bg-decoration"><div class="bg-glow-1"></div><div class="bg-glow-2"></div></div>` + renderHeader() + `<main class="main-content">${html}</main>` + renderFooter();
  window.scrollTo(0, 0);
  updateNavActive();
  mountHeroSearch();
}

// Expose rerender for PDF uploads
window.__itshRerender = renderRoute;

// ---------- Header ----------
function renderHeader() {
  const navItems = [
    { route: '', label: 'Home', icon: 'home' },
    { route: 'semesters', label: 'Semesters', icon: 'layers' },
    { route: 'practicals', label: 'Practicals', icon: 'code' },
    { route: 'academic', label: 'Academic', icon: 'clipboard' },
    { route: 'bookmarks', label: 'Bookmarks', icon: 'bookmark' },
  ];
  return `
    <header class="header">
      <div class="container header-inner">
        <a href="#/" class="logo" data-link="" aria-label="${escapeHtml(state.siteName)} home">
          <span class="logo-mark">IT</span>
          <span class="logo-text">${escapeHtml(state.siteName)}</span>
        </a>
        <nav class="nav" aria-label="Main navigation">
          ${navItems.map((n) => `<a href="#/${n.route}" class="nav-link" data-link="${n.route}" data-nav="${n.route}">${escapeHtml(n.label)}</a>`).join('')}
        </nav>
        <div class="nav-actions">
          <button class="icon-btn" data-action="search" aria-label="Search">${icon('search')}</button>
          <button class="icon-btn" data-action="theme" aria-label="Theme settings">${icon('palette')}</button>
          <button class="icon-btn" data-action="profile" aria-label="Profile">${icon('user')}</button>
          <button class="icon-btn hamburger" data-action="menu" aria-label="Menu" aria-expanded="false">${icon('menu')}</button>
        </div>
      </div>
      <div class="mobile-menu" id="mobile-menu">
        ${navItems.map((n) => `<a href="#/${n.route}" class="nav-link" data-link="${n.route}" data-nav="${n.route}">${icon(n.icon)} ${escapeHtml(n.label)}</a>`).join('')}
        <a href="#/bookmarks" class="nav-link" data-link="bookmarks">${icon('bookmark')} Bookmarks</a>
      </div>
    </header>
  `;
}

function renderFooter() {
  return `
    <footer class="footer">
      <div class="container footer-inner">
        <div class="footer-brand">
          <span class="logo-mark" style="width:28px;height:28px;font-size:0.7rem">IT</span>
          <span>${escapeHtml(state.siteName)}</span>
        </div>
        <p class="footer-copy">${escapeHtml(TAGLINE)} • Built for IT/CS Students</p>
        <div class="footer-links">
          <a href="#/semesters" data-link="semesters">Semesters</a>
          <a href="#/practicals" data-link="practicals">Practicals</a>
          <a href="#/academic" data-link="academic">Resources</a>
        </div>
      </div>
    </footer>
  `;
}

function updateNavActive() {
  const { parts } = parseRoute();
  const current = parts[0] || '';
  document.querySelectorAll('[data-nav]').forEach((el) => {
    el.classList.toggle('active', el.getAttribute('data-nav') === current);
  });
}

// ---------- Mobile menu ----------
function toggleMobileMenu(open) {
  const menu = document.getElementById('mobile-menu');
  const btn = document.querySelector('.hamburger');
  if (!menu) return;
  const isOpen = open ?? !menu.classList.contains('open');
  menu.classList.toggle('open', isOpen);
  if (btn) {
    btn.setAttribute('aria-expanded', isOpen);
    btn.innerHTML = isOpen ? icon('x') : icon('menu');
  }
}

// ---------- Hero search ----------
function mountHeroSearch() {
  const mount = document.getElementById('hero-search-mount');
  if (!mount) return;
  mount.innerHTML = searchComponent('hero');
  const input = mount.querySelector('.search-input');
  const results = mount.querySelector('.search-results');
  attachSearchEvents(input, results, mount);
}

function searchComponent(id) {
  return `
    <div class="search-wrapper">
      <div class="search-input-wrap">
        ${icon('search')}
        <input type="search" class="search-input" placeholder="Search subjects, units, practicals, papers..." aria-label="Search" id="search-${id}">
        <button class="search-clear hidden" data-search-clear aria-label="Clear search">${icon('x')}</button>
      </div>
      <div class="search-results" id="search-results-${id}"></div>
    </div>
  `;
}

function attachSearchEvents(input, results, container) {
  if (!input) return;
  const clearBtn = container.querySelector('[data-search-clear]');
  input.addEventListener('input', () => {
    const q = input.value.trim();
    if (clearBtn) clearBtn.classList.toggle('hidden', !q);
    if (!q) { results.classList.remove('open'); results.innerHTML = ''; return; }
    renderSearchDropdown(q, results);
  });
  input.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
      const q = input.value.trim();
      if (q) { window.location.hash = `/search/${encodeURIComponent(q)}`; results.classList.remove('open'); }
    }
    if (e.key === 'Escape') { input.value = ''; results.classList.remove('open'); if (clearBtn) clearBtn.classList.add('hidden'); input.blur(); }
  });
  if (clearBtn) clearBtn.addEventListener('click', () => {
    input.value = ''; clearBtn.classList.add('hidden'); results.classList.remove('open'); input.focus();
  });
  document.addEventListener('click', (e) => {
    if (container && !container.contains(e.target)) results.classList.remove('open');
  });
}

function renderSearchDropdown(query, resultsEl) {
  const q = query.toLowerCase();
  const matches = SEARCH_INDEX.filter((item) =>
    item.label.toLowerCase().includes(q) || item.type.toLowerCase().includes(q) || (item.sub && item.sub.toLowerCase().includes(q))
  ).slice(0, 20);
  if (matches.length === 0) {
    resultsEl.innerHTML = `<div class="search-empty">No results for "${escapeHtml(query)}"</div>`;
    resultsEl.classList.add('open');
    return;
  }
  // Group
  const grouped = {};
  matches.forEach((m) => { if (!grouped[m.type]) grouped[m.type] = []; grouped[m.type].push(m); });
  const order = ['Semester', 'Subject', 'Unit', 'Study Material', 'Important Questions', 'Practical', 'Assignment', 'Journal', 'Paper'];
  let html = '';
  order.filter((g) => grouped[g]).forEach((g) => {
    html += `<div class="search-category">${escapeHtml(g)}</div>`;
    grouped[g].forEach((r) => {
      const routeStr = typeof r.route === 'string' ? r.route : `/${r.route.view}`;
      html += `<a href="#${routeStr}" class="search-item" data-link="${routeStr.slice(1)}"><span class="si-label">${escapeHtml(r.label)}</span><span class="si-sub">${escapeHtml(r.sub || '')}</span></a>`;
    });
  });
  resultsEl.innerHTML = html;
  resultsEl.classList.add('open');
  // Close on click
  resultsEl.querySelectorAll('.search-item').forEach((a) => {
    a.addEventListener('click', () => resultsEl.classList.remove('open'));
  });
}

// ---------- Search modal (header button) ----------
function openSearchModal() {
  const overlay = document.createElement('div');
  overlay.className = 'modal-overlay open';
  overlay.innerHTML = `
    <div class="modal" style="max-width:560px">
      <div class="modal-header">
        <h3>${icon('search')} Search</h3>
        <button class="modal-close" data-close-modal>${icon('x')}</button>
      </div>
      <div class="modal-body">
        <div id="modal-search-mount"></div>
      </div>
    </div>
  `;
  document.body.appendChild(overlay);
  const mount = overlay.querySelector('#modal-search-mount');
  mount.innerHTML = searchComponent('modal');
  const input = mount.querySelector('.search-input');
  const results = mount.querySelector('.search-results');
  attachSearchEvents(input, results, mount);
  results.style.position = 'static';
  results.style.maxHeight = '50vh';
  input.focus();
  overlay.querySelector('[data-close-modal]').addEventListener('click', () => overlay.remove());
  overlay.addEventListener('click', (e) => { if (e.target === overlay) overlay.remove(); });
}

// ---------- Settings Panel ----------
function openSettingsPanel() {
  closeAllPanels();
  const overlay = document.createElement('div');
  overlay.className = 'side-overlay open';
  overlay.addEventListener('click', closeAllPanels);
  const panel = document.createElement('div');
  panel.className = 'side-panel open';
  panel.innerHTML = `
    <div class="side-panel-header">
      <h3>${icon('settings')} Settings</h3>
      <button class="modal-close" data-close-panel>${icon('x')}</button>
    </div>
    <div class="side-panel-body">
      ${renderThemeSection()}
      ${renderModeSection()}
      ${renderSiteNameSection()}
    </div>
  `;
  document.body.appendChild(overlay);
  document.body.appendChild(panel);
  bindSettingsEvents(panel);
}

function renderThemeSection() {
  return `
    <div class="form-group">
      <label class="form-label">Accent Theme</label>
      <div class="theme-grid">
        ${THEMES.map((t) => `
          <div class="theme-option ${state.themeId === t.id ? 'active' : ''}" data-theme-id="${t.id}">
            <div class="theme-swatch" style="background:linear-gradient(135deg, ${t.primary}, ${t.accent})"></div>
            <span class="to-name">${escapeHtml(t.name)}</span>
          </div>
        `).join('')}
      </div>
    </div>
  `;
}

function renderModeSection() {
  const modes = [
    { id: 'light', label: 'Light', icon: 'sun' },
    { id: 'dark', label: 'Dark', icon: 'moon' },
    { id: 'system', label: 'System', icon: 'monitor' },
  ];
  return `
    <div class="form-group">
      <label class="form-label">Appearance Mode</label>
      <div class="mode-grid">
        ${modes.map((m) => `
          <div class="mode-option ${state.mode === m.id ? 'active' : ''}" data-mode-id="${m.id}">
            ${icon(m.icon)}
            <span>${escapeHtml(m.label)}</span>
          </div>
        `).join('')}
      </div>
    </div>
  `;
}

function renderSiteNameSection() {
  return `
    <div class="form-group">
      <label class="form-label" for="site-name-input">Customize Website Name</label>
      <input type="text" class="form-input" id="site-name-input" value="${escapeHtml(state.siteName)}" placeholder="${DEFAULT_SITE_NAME}">
      <p class="form-hint">This name appears in the header, footer, and dashboard.</p>
    </div>
    <button class="btn btn-primary btn-block" data-save-sitename>${icon('save')} Save Settings</button>
  `;
}

function bindSettingsEvents(panel) {
  panel.querySelectorAll('[data-theme-id]').forEach((el) => {
    el.addEventListener('click', () => {
      setTheme(el.getAttribute('data-theme-id'));
      panel.querySelectorAll('[data-theme-id]').forEach((e) => e.classList.remove('active'));
      el.classList.add('active');
      toast('Theme updated', 'success');
    });
  });
  panel.querySelectorAll('[data-mode-id]').forEach((el) => {
    el.addEventListener('click', () => {
      setMode(el.getAttribute('data-mode-id'));
      panel.querySelectorAll('[data-mode-id]').forEach((e) => e.classList.remove('active'));
      el.classList.add('active');
      toast('Appearance updated', 'success');
    });
  });
  panel.querySelector('[data-save-sitename]').addEventListener('click', () => {
    const val = panel.querySelector('#site-name-input').value;
    setSiteName(val);
    renderRoute();
    toast('Website name updated', 'success');
  });
  panel.querySelector('[data-close-panel]').addEventListener('click', closeAllPanels);
}

// ---------- Profile Panel ----------
function openProfilePanel() {
  closeAllPanels();
  const overlay = document.createElement('div');
  overlay.className = 'side-overlay open';
  overlay.addEventListener('click', closeAllPanels);
  const panel = document.createElement('div');
  panel.className = 'side-panel open';
  const initials = (state.profile.name || 'S').charAt(0).toUpperCase();
  panel.innerHTML = `
    <div class="side-panel-header">
      <h3>${icon('user')} Profile</h3>
      <button class="modal-close" data-close-panel>${icon('x')}</button>
    </div>
    <div class="side-panel-body">
      <div class="profile-header">
        <div class="profile-avatar">${escapeHtml(initials)}</div>
        <div class="profile-info">
          <h3>${escapeHtml(state.profile.name)}</h3>
          <p>${escapeHtml(state.profile.course)} • Semester ${state.profile.semester}</p>
        </div>
      </div>
      <div class="form-group">
        <label class="form-label" for="prof-name">Student Name</label>
        <input type="text" class="form-input" id="prof-name" value="${escapeHtml(state.profile.name)}">
      </div>
      <div class="form-group">
        <label class="form-label" for="prof-course">Course</label>
        <input type="text" class="form-input" id="prof-course" value="${escapeHtml(state.profile.course)}">
      </div>
      <div class="form-group">
        <label class="form-label" for="prof-sem">Semester</label>
        <select class="form-select" id="prof-sem">
          ${[1,2,3,4,5,6,7,8].map((n) => `<option value="${n}" ${state.profile.semester == n ? 'selected' : ''}>Semester ${n}</option>`).join('')}
        </select>
      </div>
      <button class="btn btn-primary btn-block mb-16" data-save-profile>${icon('save')} Save Profile</button>
      <div class="dash-panel" style="padding:16px;background:var(--surface-2)">
        <div class="flex items-center justify-between mb-16">
          <strong style="font-size:0.9rem">${icon('bookmark')} Bookmarks</strong>
          <span style="color:var(--text-muted);font-size:0.85rem">${state.bookmarks.length}</span>
        </div>
        <div class="flex items-center justify-between">
          <strong style="font-size:0.9rem">${icon('clock')} Recently Viewed</strong>
          <span style="color:var(--text-muted);font-size:0.85rem">${state.recent.length}</span>
        </div>
      </div>
    </div>
  `;
  document.body.appendChild(overlay);
  document.body.appendChild(panel);
  panel.querySelector('[data-save-profile]').addEventListener('click', () => {
    setProfile({
      name: panel.querySelector('#prof-name').value || 'Student',
      course: panel.querySelector('#prof-course').value || 'B.Tech IT',
      semester: Number(panel.querySelector('#prof-sem').value),
    });
    toast('Profile saved', 'success');
    closeAllPanels();
    renderRoute();
  });
  panel.querySelector('[data-close-panel]').addEventListener('click', closeAllPanels);
}

function closeAllPanels() {
  document.querySelectorAll('.side-panel.open').forEach((p) => p.classList.remove('open'));
  document.querySelectorAll('.side-overlay.open').forEach((o) => o.remove());
  setTimeout(() => {
    document.querySelectorAll('.side-panel').forEach((p) => { if (!p.classList.contains('open')) p.remove(); });
  }, 300);
}

// ---------- Global event delegation ----------
function setupGlobalEvents() {
  document.addEventListener('click', (e) => {
    const target = e.target.closest('[data-link], [data-action], [data-bookmark], [data-pdf-upload], [data-remove-pdf], [data-copy-code], [data-toggle-unit], [data-unit-tab], [data-unit-content-tab], [data-clear-bookmarks], [data-close-modal]');

    // Handle data-link (SPA navigation)
    const link = e.target.closest('[data-link]');
    if (link) {
      e.preventDefault();
      const route = link.getAttribute('data-link');
      window.location.hash = `/${route}`;
      toggleMobileMenu(false);
      return;
    }

    // Handle actions
    const action = e.target.closest('[data-action]');
    if (action) {
      const a = action.getAttribute('data-action');
      if (a === 'search') openSearchModal();
      else if (a === 'theme') openSettingsPanel();
      else if (a === 'profile') openProfilePanel();
      else if (a === 'menu') toggleMobileMenu();
      return;
    }

    // Bookmark
    const bm = e.target.closest('[data-bookmark]');
    if (bm) { handleBookmarkClick(bm); return; }

    // PDF upload
    const upload = e.target.closest('[data-pdf-upload]');
    if (upload) { handlePdfUpload(upload); return; }

    // Remove PDF
    const rm = e.target.closest('[data-remove-pdf]');
    if (rm) { handleRemovePdf(rm.getAttribute('data-remove-pdf')); return; }

    // Copy code
    const copy = e.target.closest('[data-copy-code]');
    if (copy) { handleCopyCode(copy); return; }

    // Unit accordion toggle
    const toggle = e.target.closest('[data-toggle-unit]');
    if (toggle) {
      const unitNum = toggle.getAttribute('data-toggle-unit');
      const item = toggle.closest('.accordion-item');
      const isOpen = item.classList.contains('open');
      // Close all, open clicked
      document.querySelectorAll('.accordion-item.open').forEach((i) => {
        i.classList.remove('open');
        i.querySelector('.accordion-body').style.maxHeight = '0';
        i.querySelector('.accordion-header').setAttribute('aria-expanded', 'false');
      });
      if (!isOpen) {
        item.classList.add('open');
        const body = item.querySelector('.accordion-body');
        body.style.maxHeight = body.scrollHeight + 'px';
        toggle.setAttribute('aria-expanded', 'true');
        // Update tabs active state
        document.querySelectorAll('[data-unit-tab]').forEach((t) => t.classList.toggle('active', t.getAttribute('data-unit-tab') === unitNum));
      }
      return;
    }

    // Unit tab (top tabs)
    const unitTab = e.target.closest('[data-unit-tab]');
    if (unitTab) {
      const unitNum = unitTab.getAttribute('data-unit-tab');
      document.querySelectorAll('[data-unit-tab]').forEach((t) => t.classList.remove('active'));
      unitTab.classList.add('active');
      // Open the matching accordion
      const target = document.querySelector(`.accordion-item[data-unit="${unitNum}"]`);
      if (target && !target.classList.contains('open')) {
        target.querySelector('[data-toggle-unit]').click();
        target.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
      return;
    }

    // Unit content tab (material/notes/questions/reference)
    const contentTab = e.target.closest('[data-unit-content-tab]');
    if (contentTab) {
      const tabId = contentTab.getAttribute('data-unit-content-tab');
      const unitNum = contentTab.getAttribute('data-unit-num');
      const item = document.querySelector(`.accordion-item[data-unit="${unitNum}"]`);
      if (item) {
        item.querySelectorAll('[data-unit-content-tab]').forEach((t) => t.classList.remove('active'));
        contentTab.classList.add('active');
        // Re-render content: find the unit and tab
        const semNum = getSemFromDom();
        const subIdx = getSubFromDom();
        const sub = SEMESTERS.find((s) => s.number === semNum)?.subjects[subIdx];
        const unit = sub?.units.find((u) => u.number === Number(unitNum));
        if (unit) {
          const contentEl = item.querySelector('.unit-content');
          // Import dynamically is messy; inline the render
          contentEl.innerHTML = renderUnitTabInline(sub, unit, tabId);
          // After re-render, ensure accordion body height is recalculated
          const body = item.querySelector('.accordion-body');
          body.style.maxHeight = body.scrollHeight + 'px';
        }
      }
      return;
    }

    // Clear all bookmarks
    const clearBm = e.target.closest('[data-clear-bookmarks]');
    if (clearBm) {
      if (state.bookmarks.length === 0) return;
      state.bookmarks = [];
      state.persistBookmarks();
      toast('All bookmarks cleared', 'info');
      renderRoute();
      return;
    }

    // Close modal
    const closeMod = e.target.closest('[data-close-modal]');
    if (closeMod) {
      closeMod.closest('.modal-overlay').remove();
      return;
    }
  });

  // Listen for system theme changes
  window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', () => {
    if (state.mode === 'system') applyMode();
  });

  // Hash change
  window.addEventListener('hashchange', renderRoute);
}

// Helper: get current semester/subject from DOM breadcrumb context
function getSemFromDom() {
  const breadcrumb = document.querySelector('.breadcrumb');
  if (!breadcrumb) return null;
  // Parse from hash
  const parts = window.location.hash.slice(1).split('/').filter(Boolean);
  if (parts[0] === 'semester' && parts[1]) return Number(parts[1]);
  return null;
}

function getSubFromDom() {
  const parts = window.location.hash.slice(1).split('/').filter(Boolean);
  if (parts[0] === 'semester' && parts[1] && parts[2] === 'subject' && parts[3] != null) return Number(parts[3]);
  return null;
}

// Inline render for unit tab content (avoids circular import)
function renderUnitTabInline(sub, unit, tab) {
  const { pdfViewer, escapeHtml, bookmarkButton } = InlineHelpers;
  if (tab === 'material') {
    return `<p>${escapeHtml(unit.studyMaterial)}</p>${pdfViewer(unit.id, 'Study Material PDF')}`;
  }
  if (tab === 'notes') {
    return `<p>${escapeHtml(unit.notes)}</p>`;
  }
  if (tab === 'questions') {
    const bm = { id: `${unit.id}-questions`, label: `${unit.title} — Questions`, sub: sub.name, type: 'Important Questions', route: `semester/${sub.semester}/subject/${sub.index}/unit/${unit.number}/questions` };
    return `<h4>Important Questions</h4><ul class="bullet">${unit.importantQuestions.map((q) => `<li>${escapeHtml(q)}</li>`).join('')}</ul><div class="mt-16">${bookmarkButton(bm)}</div>`;
  }
  if (tab === 'reference') {
    return `<p>${escapeHtml(unit.referenceMaterial)}</p>${pdfViewer(`${unit.id}-ref`, 'Reference PDF')}`;
  }
  return '';
}

// Import helpers for inline rendering
import { pdfViewer as _pdfViewer, escapeHtml as _escapeHtml, bookmarkButton as _bookmarkButton } from './ui.js';
const InlineHelpers = { pdfViewer: _pdfViewer, escapeHtml: _escapeHtml, bookmarkButton: _bookmarkButton };

// ---------- Init ----------
function init() {
  applyTheme();
  applyMode();
  setupGlobalEvents();
  renderRoute();
}

init();
