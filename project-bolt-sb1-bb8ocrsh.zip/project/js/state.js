// ============================================================
// ITStudyHub — State Module
// Manages bookmarks, recently viewed, settings (theme, dark mode,
// site name, profile) using localStorage persistence.
// ============================================================

import { THEMES, DEFAULT_SITE_NAME } from './data.js';

const KEYS = {
  bookmarks: 'itsh_bookmarks',
  recent: 'itsh_recent',
  theme: 'itsh_theme',
  mode: 'itsh_mode',
  siteName: 'itsh_site_name',
  profile: 'itsh_profile',
  pdfs: 'itsh_pdfs',
};

function load(key, fallback) {
  try {
    const raw = localStorage.getItem(key);
    return raw ? JSON.parse(raw) : fallback;
  } catch {
    return fallback;
  }
}

function save(key, value) {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch (e) {
    // localStorage may be full from large PDF data URLs
    console.warn('Storage save failed:', e);
  }
}

export const state = {
  bookmarks: load(KEYS.bookmarks, []),
  recent: load(KEYS.recent, []),
  themeId: load(KEYS.theme, 'professional'),
  mode: load(KEYS.mode, 'system'), // 'light' | 'dark' | 'system'
  siteName: load(KEYS.siteName, DEFAULT_SITE_NAME),
  profile: load(KEYS.profile, { name: 'Student', course: 'B.Tech IT', semester: 1, avatar: '' }),
  pdfs: load(KEYS.pdfs, {}), // { unitId|resId: dataUrl }

  persistBookmarks() { save(KEYS.bookmarks, this.bookmarks); },
  persistRecent() { save(KEYS.recent, this.recent); },
  persistTheme() { save(KEYS.theme, this.themeId); },
  persistMode() { save(KEYS.mode, this.mode); },
  persistSiteName() { save(KEYS.siteName, this.siteName); },
  persistProfile() { save(KEYS.profile, this.profile); },
  persistPdfs() { save(KEYS.pdfs, this.pdfs); },
};

// ---- Bookmark helpers ----
export function addBookmark(item) {
  if (!state.bookmarks.some((b) => b.id === item.id)) {
    state.bookmarks.unshift(item);
    state.persistBookmarks();
  }
}

export function removeBookmark(id) {
  state.bookmarks = state.bookmarks.filter((b) => b.id !== id);
  state.persistBookmarks();
}

export function isBookmarked(id) {
  return state.bookmarks.some((b) => b.id === id);
}

export function toggleBookmark(item) {
  if (isBookmarked(item.id)) {
    removeBookmark(item.id);
    return false;
  }
  addBookmark(item);
  return true;
}

// ---- Recently viewed ----
export function addRecent(item) {
  state.recent = state.recent.filter((r) => r.id !== item.id);
  state.recent.unshift(item);
  state.recent = state.recent.slice(0, 12);
  state.persistRecent();
}

// ---- Theme helpers ----
export function applyTheme() {
  const theme = THEMES.find((t) => t.id === state.themeId) || THEMES[1];
  const root = document.documentElement;
  root.style.setProperty('--primary', theme.primary);
  root.style.setProperty('--primary-dark', theme.primaryDark);
  root.style.setProperty('--accent', theme.accent);
  root.style.setProperty('--bg-glow', theme.bgGlow);
}

export function applyMode() {
  const root = document.documentElement;
  let dark;
  if (state.mode === 'system') {
    dark = window.matchMedia('(prefers-color-scheme: dark)').matches;
  } else {
    dark = state.mode === 'dark';
  }
  root.setAttribute('data-mode', dark ? 'dark' : 'light');
}

export function setTheme(id) {
  state.themeId = id;
  state.persistTheme();
  applyTheme();
}

export function setMode(mode) {
  state.mode = mode;
  state.persistMode();
  applyMode();
}

export function setSiteName(name) {
  state.siteName = name.trim() || DEFAULT_SITE_NAME;
  state.persistSiteName();
}

export function setProfile(profile) {
  state.profile = { ...state.profile, ...profile };
  state.persistProfile();
}

// ---- PDF storage (localStorage data URLs; demo only) ----
export function setPdf(id, dataUrl) {
  state.pdfs[id] = dataUrl;
  state.persistPdfs();
}
export function getPdf(id) {
  return state.pdfs[id] || null;
}
export function removePdf(id) {
  delete state.pdfs[id];
  state.persistPdfs();
}

export function getCurrentTheme() {
  return THEMES.find((t) => t.id === state.themeId) || THEMES[1];
}
