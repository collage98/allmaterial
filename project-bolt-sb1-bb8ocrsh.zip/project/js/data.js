// ============================================================
// ITStudyHub — Data Module
// Defines the academic content architecture:
//   Semesters → Subjects → Units → Study Materials
//   Practicals, Academic Resources (Assignments / Journals / Papers)
// ============================================================

const SUBJECT_NAMES = {
  1: ['Programming in C', 'Digital Electronics', 'Mathematics-I', 'Communication Skills', 'Computer Fundamentals', 'Engineering Physics', 'Engineering Chemistry'],
  2: ['Data Structures', 'Discrete Mathematics', 'Mathematics-II', 'Computer Organization', 'OOP in C++', 'Basic Electronics', 'Environmental Science'],
  3: ['Algorithms', 'Operating Systems', 'DBMS', 'Theory of Computation', 'Computer Networks', 'Software Engineering', 'Web Technologies'],
  4: ['Java Programming', 'Microprocessor', 'Computer Graphics', 'Object Oriented Analysis', 'Digital Signal Processing', 'Probability & Statistics', 'Technical Communication'],
  5: ['Python Programming', 'Cloud Computing', 'Artificial Intelligence', 'Mobile Computing', 'Information Security', 'Data Warehousing', 'Advanced DBMS'],
  6: ['Machine Learning', 'Compiler Design', 'Distributed Systems', 'Cyber Security', 'Big Data Analytics', 'Internet of Things', 'Cryptography'],
  7: ['Deep Learning', 'Blockchain Technology', 'DevOps', 'Natural Language Processing', 'Software Project Management', 'Human Computer Interaction', 'Data Mining'],
  8: ['Computer Vision', 'Quantum Computing', 'Robotics', 'Ethical Hacking', 'Capstone Project', 'Cloud Architecture', 'Industrial Training'],
};

const SEMESTER_THEMES = {
  1: 'Foundations of Computing', 2: 'Logic & Data Structures', 3: 'Core Systems',
  4: 'Applied Programming', 5: 'Modern Computing', 6: 'Intelligent Systems',
  7: 'Advanced Specialization', 8: 'Capstone & Industry',
};

// Practical templates per semester (rotated subject focus)
const PRACTICAL_TEMPLATES = [
  { title: 'Program Control Flow', problem: 'Write a program to demonstrate loops and conditional statements.', objective: 'Understand control flow constructs in C.', code: '#include <stdio.h>\n\nint main() {\n    int n = 10;\n    for (int i = 1; i <= n; i++) {\n        if (i % 2 == 0)\n            printf("%d is even\\n", i);\n        else\n            printf("%d is odd\\n", i);\n    }\n    return 0;\n}' },
  { title: 'Array Operations', problem: 'Implement insertion, deletion, and traversal on a 1-D array.', objective: 'Master basic array operations and memory layout.', code: '#include <stdio.h>\n\nint main() {\n    int arr[10] = {1, 2, 3, 4, 5};\n    int n = 5;\n    // insert 99 at index 2\n    for (int i = n; i > 2; i--) arr[i] = arr[i-1];\n    arr[2] = 99; n++;\n    for (int i = 0; i < n; i++) printf("%d ", arr[i]);\n    return 0;\n}' },
  { title: 'Stack Using Array', problem: 'Implement push, pop, and peek operations on a stack.', objective: 'Learn LIFO behavior and stack operations.', code: '#define MAX 100\nint stack[MAX], top = -1;\nvoid push(int x) { if (top < MAX-1) stack[++top] = x; }\nint pop() { return (top >= 0) ? stack[top--] : -1; }' },
  { title: 'Queue Using Array', problem: 'Implement enqueue and dequeue for a linear queue.', objective: 'Understand FIFO behavior and queue operations.', code: '#define MAX 100\nint queue[MAX], front=0, rear=-1;\nvoid enqueue(int x){ if(rear<MAX-1) queue[++rear]=x; }\nint dequeue(){ return (front<=rear) ? queue[front++] : -1; }' },
  { title: 'Linked List Operations', problem: 'Create, insert, and delete nodes in a singly linked list.', objective: 'Master dynamic memory and pointer manipulation.', code: 'struct Node { int data; struct Node* next; };\n// insert at end\nvoid insertEnd(struct Node** head, int data) {\n    struct Node* n = malloc(sizeof(struct Node));\n    n->data = data; n->next = NULL;\n    if (!*head) { *head = n; return; }\n    struct Node* t = *head;\n    while (t->next) t = t->next;\n    t->next = n;\n}' },
  { title: 'Binary Tree Traversal', problem: 'Implement inorder, preorder, and postorder traversal.', objective: 'Understand tree data structures and recursion.', code: 'struct Node { int data; struct Node *left, *right; };\nvoid inorder(struct Node* r){\n    if(!r) return;\n    inorder(r->left);\n    printf("%d ", r->data);\n    inorder(r->right);\n}' },
  { title: 'Sorting Algorithm', problem: 'Implement bubble sort and measure comparisons.', objective: 'Understand sorting complexity and comparison counts.', code: 'void bubbleSort(int a[], int n) {\n    for (int i = 0; i < n-1; i++)\n        for (int j = 0; j < n-i-1; j++)\n            if (a[j] > a[j+1]) {\n                int t = a[j]; a[j] = a[j+1]; a[j+1] = t;\n            }\n}' },
  { title: 'Searching Technique', problem: 'Implement linear and binary search on a sorted array.', objective: 'Compare search algorithm efficiency.', code: 'int binarySearch(int a[], int n, int key) {\n    int lo=0, hi=n-1;\n    while (lo<=hi) {\n        int mid=(lo+hi)/2;\n        if (a[mid]==key) return mid;\n        if (a[mid]<key) lo=mid+1; else hi=mid-1;\n    }\n    return -1;\n}' },
];

const VIVA_QUESTIONS = [
  'What is the time complexity of this algorithm?',
  'Explain the core data structure used here.',
  'What are the edge cases to handle?',
  'How would you optimize this solution further?',
  'Explain the difference between best, average, and worst case.',
];

// Build the full academic tree dynamically
function buildData() {
  const semesters = [];
  for (let s = 1; s <= 8; s++) {
    const subjects = [];
    for (let sub = 0; sub < 7; sub++) {
      const subjectId = `s${s}-sub${sub + 1}`;
      const subjectName = SUBJECT_NAMES[s][sub];
      const units = [];
      for (let u = 1; u <= 5; u++) {
        units.push({
          id: `${subjectId}-u${u}`,
          number: u,
          title: `Unit ${u}: ${getUnitTitle(s, sub, u)}`,
          studyMaterial: `Study material for ${subjectName} — Unit ${u}. Covers key concepts, worked examples, and theory.`,
          notes: `Concise notes for ${subjectName} Unit ${u}. Ideal for quick revision before exams.`,
          importantQuestions: [
            `Q1. Explain the core concept of ${getUnitTitle(s, sub, u)}.`,
            `Q2. Compare and contrast the key approaches in this unit.`,
            `Q3. Solve a representative problem with step-by-step reasoning.`,
            `Q4. Discuss real-world applications of this topic.`,
            `Q5. Short note on the significance of this unit in the subject.`,
          ],
          referenceMaterial: `Reference textbook chapter + curated online resources for ${subjectName} Unit ${u}.`,
          pdfUrl: null, // set when a user uploads a PDF (stored as data URL in localStorage)
        });
      }
      // Practical: every subject has 1 practical for demo
      const tpl = PRACTICAL_TEMPLATES[sub % PRACTICAL_TEMPLATES.length];
      const practical = {
        id: `${subjectId}-prac`,
        number: sub + 1,
        title: `Practical ${sub + 1}: ${subjectName} — ${tpl.title}`,
        problemStatement: tpl.problem,
        objective: tpl.objective,
        sourceCode: tpl.code,
        explanation: `This practical demonstrates ${tpl.title.toLowerCase()} within ${subjectName}. The code is annotated to illustrate each step. Trace through the logic with sample inputs to verify correctness.`,
        output: `Sample Output:\n> Compilation successful\n> Program executed\n> Result verified against expected values`,
        vivaQuestions: VIVA_QUESTIONS,
        referencePdfUrl: null,
      };
      subjects.push({
        id: subjectId,
        name: subjectName,
        index: sub,
        semester: s,
        units,
        practical,
        academic: {
          assignment: { id: `${subjectId}-assign`, title: `Assignment — ${subjectName}`, pdfUrl: null, description: `Assignment questions for ${subjectName}.` },
          journal: { id: `${subjectId}-journal`, title: `Journal — ${subjectName}`, pdfUrl: null, description: `Lab journal entries for ${subjectName}.` },
          paper: { id: `${subjectId}-paper`, title: `Question Paper — ${subjectName}`, pdfUrl: null, description: `Previous year question paper for ${subjectName}.` },
        },
      });
    }
    semesters.push({
      id: `sem${s}`,
      number: s,
      title: `Semester ${s}`,
      theme: SEMESTER_THEMES[s],
      subjectCount: 7,
      unitCount: 35,
      practicalsAvailable: true,
      subjects,
    });
  }
  return semesters;
}

function getUnitTitle(semester, subjectIndex, unit) {
  const topicBanks = [
    ['Introduction & Basics', 'Core Concepts', 'Advanced Topics', 'Applications', 'Case Studies & Review'],
    ['Fundamentals', 'Data Representation', 'Processing Techniques', 'Optimization', 'Modern Trends'],
    ['Overview & History', 'Theoretical Foundations', 'Design Principles', 'Implementation', 'Evaluation & Testing'],
  ];
  const bank = topicBanks[(semester + subjectIndex) % topicBanks.length];
  return bank[(unit - 1) % bank.length];
}

// Enriched index for fast global search
function buildSearchIndex(semesters) {
  const items = [];
  semesters.forEach((sem) => {
    items.push({ type: 'Semester', label: sem.title, sub: sem.theme, route: { view: 'semester', sem: sem.number } });
    sem.subjects.forEach((sub) => {
      items.push({ type: 'Subject', label: sub.name, sub: `Semester ${sem.number}`, route: { view: 'subject', sem: sem.number, sub: sub.index } });
      sub.units.forEach((u) => {
        items.push({ type: 'Unit', label: u.title, sub: sub.name, route: { view: 'subject', sem: sem.number, sub: sub.index, unit: u.number } });
        items.push({ type: 'Important Questions', label: `${u.title} — Questions`, sub: sub.name, route: { view: 'subject', sem: sem.number, sub: sub.index, unit: u.number, tab: 'questions' } });
        items.push({ type: 'Study Material', label: `${u.title} — Material`, sub: sub.name, route: { view: 'subject', sem: sem.number, sub: sub.index, unit: u.number, tab: 'material' } });
      });
      items.push({ type: 'Practical', label: sub.practical.title, sub: sub.name, route: { view: 'practical-detail', sem: sem.number, sub: sub.index } });
      items.push({ type: 'Assignment', label: sub.academic.assignment.title, sub: sub.name, route: { view: 'academic-detail', sem: sem.number, sub: sub.index, res: 'assignment' } });
      items.push({ type: 'Journal', label: sub.academic.journal.title, sub: sub.name, route: { view: 'academic-detail', sem: sem.number, sub: sub.index, res: 'journal' } });
      items.push({ type: 'Paper', label: sub.academic.paper.title, sub: sub.name, route: { view: 'academic-detail', sem: sem.number, sub: sub.index, res: 'paper' } });
    });
  });
  return items;
}

export const SEMESTERS = buildData();
export const SEARCH_INDEX = buildSearchIndex(SEMESTERS);

export const THEMES = [
  { id: 'ocean', name: 'Ocean Blue', primary: '#0284c7', primaryDark: '#0369a1', accent: '#0ea5e9', bgGlow: 'rgba(14,165,233,0.15)' },
  { id: 'professional', name: 'Professional Blue', primary: '#2563eb', primaryDark: '#1d4ed8', accent: '#3b82f6', bgGlow: 'rgba(59,130,246,0.15)' },
  { id: 'royal', name: 'Royal Purple', primary: '#7c3aed', primaryDark: '#6d28d9', accent: '#8b5cf6', bgGlow: 'rgba(139,92,246,0.15)' },
  { id: 'emerald', name: 'Emerald', primary: '#059669', primaryDark: '#047857', accent: '#10b981', bgGlow: 'rgba(16,185,129,0.15)' },
  { id: 'midnight', name: 'Midnight', primary: '#4f46e5', primaryDark: '#4338ca', accent: '#6366f1', bgGlow: 'rgba(99,102,241,0.15)' },
  { id: 'sunset', name: 'Sunset', primary: '#ea580c', primaryDark: '#c2410c', accent: '#f97316', bgGlow: 'rgba(249,115,22,0.15)' },
];

export const DEFAULT_SITE_NAME = 'ITStudyHub';
export const TAGLINE = 'Learn • Practice • Prepare • Succeed';
