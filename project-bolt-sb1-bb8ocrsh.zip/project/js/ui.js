// ============================================================
// ITStudyHub — UI Helpers
// Toast notifications, modals, breadcrumbs, PDF viewer,
// code viewer, bookmark buttons, and shared utilities.
// ============================================================

import { icon } from './icons.js';
import { isBookmarked, toggleBookmark, getPdf, setPdf, removePdf } from './state.js';
import { SEMESTERS } from './data.js';

// ---------- Utilities ----------
export function escapeHtml(str) {
  if (str == null) return '';
  return String(str).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

export function getSemester(num) {
  return SEMESTERS.find((s) => s.number === Number(num));
}

export function getSubject(semNum, subIndex) {
  const sem = getSemester(semNum);
  if (!sem) return null;
  return sem.subjects[Number(subIndex)];
}

export function getUnit(semNum, subIndex, unitNum) {
  const sub = getSubject(semNum, subIndex);
  if (!sub) return null;
  return sub.units.find((u) => u.number === Number(unitNum));
}

// ---------- Toast ----------
export function toast(message, type = 'info') {
  let container = document.querySelector('.toast-container');
  if (!container) {
    container = document.createElement('div');
    container.className = 'toast-container';
    document.body.appendChild(container);
  }
  const iconName = type === 'success' ? 'check' : type === 'error' ? 'alertCircle' : 'info';
  const el = document.createElement('div');
  el.className = `toast ${type}`;
  el.innerHTML = `${icon(iconName)}<span>${escapeHtml(message)}</span>`;
  container.appendChild(el);
  setTimeout(() => {
    el.classList.add('out');
    setTimeout(() => el.remove(), 300);
  }, 2800);
}

// ---------- Breadcrumb ----------
export function breadcrumb(items) {
  return `<nav class="breadcrumb" aria-label="Breadcrumb">${items
    .map((it, i) => {
      const last = i === items.length - 1;
      if (last) return `<span class="current">${escapeHtml(it.label)}</span>`;
      return `<a href="#/${it.route}" data-link="${it.route}">${escapeHtml(it.label)}</a><span class="sep">${icon('chevronRight')}</span>`;
    })
    .join('')}</nav>`;
}

// ---------- Bookmark Button ----------
export function bookmarkButton(item) {
  const active = isBookmarked(item.id);
  return `<button class="bookmark-btn ${active ? 'active' : ''}" data-bookmark='${escapeAttr(JSON.stringify(item))}' aria-label="${active ? 'Remove bookmark' : 'Add bookmark'}" aria-pressed="${active}">${active ? icon('bookmarkFill') : icon('bookmark')}</button>`;
}

function escapeAttr(str) {
  return String(str).replace(/'/g, '&#39;');
}

// Handle bookmark toggle via event delegation
export function handleBookmarkClick(btn) {
  const raw = btn.getAttribute('data-bookmark');
  if (!raw) return;
  const item = JSON.parse(raw.replace(/&#39;/g, "'"));
  const added = toggleBookmark(item);
  btn.classList.toggle('active', added);
  btn.setAttribute('aria-pressed', added);
  btn.setAttribute('aria-label', added ? 'Remove bookmark' : 'Add bookmark');
  btn.innerHTML = added ? icon('bookmarkFill') : icon('bookmark');
  toast(added ? 'Added to bookmarks' : 'Removed from bookmarks', added ? 'success' : 'info');
}

// ---------- PDF Viewer Component ----------
export function pdfViewer(pdfKey, label = 'Study Material') {
  const url = getPdf(pdfKey);
  const hasPdf = !!url;
  const id = `pdf-${pdfKey.replace(/[^a-zA-Z0-9]/g, '-')}`;
  return `
    <div class="pdf-section">
      <div class="flex items-center justify-between mb-16">
        <h4 class="flex items-center gap-8" style="font-size:0.95rem;font-weight:700">${icon('fileText')} ${escapeHtml(label)}</h4>
      </div>
      ${hasPdf ? `
        <div class="pdf-viewer-wrap">
          <iframe src="${url}" title="${escapeAttr(label)}" aria-label="PDF viewer for ${escapeAttr(label)}"></iframe>
        </div>
        <div class="pdf-actions">
          <span class="pdf-name">${icon('fileText')} PDF loaded — view only</span>
          <button class="btn btn-sm btn-ghost" data-remove-pdf="${escapeAttr(pdfKey)}">${icon('trash')} Remove PDF</button>
        </div>
      ` : `
        <div class="pdf-empty">
          ${icon('uploadCloud')}
          <p>No PDF added yet. Upload a PDF to embed it here for viewing.</p>
          <label class="btn btn-primary btn-sm mt-16 pdf-upload-label">
            ${icon('upload')} Upload PDF
            <input type="file" accept="application/pdf" hidden data-pdf-upload="${escapeAttr(pdfKey)}">
          </label>
        </div>
      `}
    </div>
  `;
}

// Handle PDF upload via event delegation
export function handlePdfUpload(input) {
  const key = input.getAttribute('data-pdf-upload');
  const file = input.files[0];
  if (!file) return;
  if (file.type !== 'application/pdf') {
    toast('Please select a PDF file', 'error');
    return;
  }
  if (file.size > 8 * 1024 * 1024) {
    toast('PDF too large (max 8MB for browser storage)', 'error');
    return;
  }
  const reader = new FileReader();
  reader.onload = () => {
    setPdf(key, reader.result);
    toast('PDF uploaded successfully', 'success');
    // Re-render current view
    if (window.__itshRerender) window.__itshRerender();
  };
  reader.onerror = () => toast('Failed to read PDF', 'error');
  reader.readAsDataURL(file);
}

export function handleRemovePdf(key) {
  removePdf(key);
  toast('PDF removed', 'info');
  if (window.__itshRerender) window.__itshRerender();
}

// ---------- Code Viewer ----------
export function codeViewer(code, lang = 'C') {
  return `
    <div class="code-viewer">
      <div class="code-header">
        <span class="code-lang">${escapeHtml(lang)}</span>
        <button class="code-copy" data-copy-code aria-label="Copy code">${icon('copy')} <span>Copy</span></button>
      </div>
      <pre class="code-block"><code>${escapeHtml(code)}</code></pre>
    </div>
  `;
}

export function handleCopyCode(btn) {
  const code = btn.closest('.code-viewer').querySelector('code').textContent;
  navigator.clipboard.writeText(code).then(() => {
    btn.classList.add('copied');
    btn.innerHTML = `${icon('check')} <span>Copied</span>`;
    toast('Code copied to clipboard', 'success');
    setTimeout(() => {
      btn.classList.remove('copied');
      btn.innerHTML = `${icon('copy')} <span>Copy</span>`;
    }, 2000);
  });
}

// ---------- Empty State ----------
export function emptyState(title, desc, iconName = 'folder') {
  return `<div class="empty-state">${icon(iconName)}<h3>${escapeHtml(title)}</h3><p>${escapeHtml(desc)}</p></div>`;
}

// ---------- Section helper ----------
export function sectionWrap(title, subtitle, content) {
  return `
    <section class="section">
      <div class="container">
        ${title ? `<div class="section-header"><h2 class="section-title">${escapeHtml(title)}</h2>${subtitle ? `<p class="section-subtitle">${escapeHtml(subtitle)}</p>` : ''}</div>` : ''}
        ${content}
      </div>
    </section>
  `;
}
